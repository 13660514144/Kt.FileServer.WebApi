//获取大厦
function edifices() {
    var url;
}
function CreatHead() {
	var PostHeader = {
		timestamp: parseInt((new Date()).valueOf() / 1000),
		nonce: guid(),
		token: Token,
		platform: "PC",
		version: "1.0.0",
		secret: Secret,
		sign: ""
	};
	var md5 = 'nonce=' + PostHeader.nonce + '&platform=PC&timestamp=' + PostHeader.timestamp + '&token=' + Token + '&version=1.0.0&secret=' + Secret;
	var md5str = hex_md5(md5);
	PostHeader.sign = md5str.toLowerCase();
	console.log(JSON.stringify(PostHeader));
	return PostHeader;
}
function buildTree(arr)
{
	if(arr.length<=0)
	{
		return;
	}

	var section=document.getElementById('help-left');
	section.innerHTML='';
	var effid;
	var div='';

	for(var x=0;x<arr.length;x++)
	{
		effid=arr[x].id;
		div +='<details class="menu" close>';
		div +='<summary>'+arr[x].name+'</summary>';
		div +='<ul>';
		var nodes=arr[x].nodes;
		for(var y=0;y<nodes.length;y++)
		{
			div +='<li><a href="#" onclick="passageway('+effid+','+nodes[y].id+')">'+nodes[y].name+'</a></li>';
		}
		div +='</ul>';
		div +='</details>';
	}
	section.innerHTML=div;
}
function passageway(effid,floorid)
{
	var http=BaseUrl+equipment;
	var data={
		edificeId:effid,
		floorId:floorid
	};
	_PopMsg();
	_AsyncRequest._AsyncPost(data, 'CallBacklpassageway', http,true,CreatHead(),'JSON');
}	
function CallBacklpassageway(data)
{	
	_ErrMsg(data.message);
	if(data.code=200)
	{
		buildpassageway(data.data);
	}
}
function buildpassageway(arr)
{
	var efgroup=document.getElementById('efgroup');
	console.log(JSON.stringify(arr));
	efgroup.innerHTML='';
	if(arr.length<=0)
	{
		return;
	}
	for(var x=0;x<arr.length;x++)
	{
		efgroup.innerHTML+='<div class="divtitle" style="float:left" id="groupname">'+arr[x].name+'</div>';
		efgroup.innerHTML+='<div id="groupconent">';
		var groupid=arr[x].id;
		var passageways=arr[x].passageways;
		var div='';
		
		for(var y=0;y<passageways.length;y++)
		{
			div +='<div class="col">';
			div +='<div class="divtitle2">'+passageways[y].name+'</div>';    
			div +='	<div class="box">';
			div +='	<ul>';
			div +='	<li>入口';
			div +='	<a href="#" class="button delete" style="color:#f56c6c;background:#FFF3EF;" onclick="openalways('+passageways[y].id+','+groupid+',\'INLET\',false)">常闭</a>'
			div +='	<a href="#" class="button edit" style="color:#67c23a;background:#F0FBEB;" onclick="openalways('+passageways[y].id+','+groupid+',\'INLET\',true)">常开</a>'
			div +='	<a href="#" class="button add" style="color:#409eff;background:#EFF6FF;" onclick="opendoor('+passageways[y].id+','+groupid+',\'INLET\')">开闸</a>'
			div +='	</li>';
			div +='	<li >出口';			
			div +='	<a href="#" class="button delete" style="color:#f56c6c;background:#FFF3EF;" onclick="openalways('+passageways[y].id+','+groupid+',\'OUTLET\',false)">常闭</a>';
			div +='	<a href="#" class="button edit"  style="color:#67c23a;background:#F0FBEB;" onclick="openalways('+passageways[y].id+','+groupid+',\'OUTLET\',true)">常开</a>';				
			div +='	<a href="#" class="button add" style="color:#409eff;background:#EFF6FF;" onclick="opendoor('+passageways[y].id+','+groupid+',\'OUTLET\')">开闸</a>';
			div +='	</li>';
			div +='	</ul>';	
			div +='	</div>';
			div +='</div>';		
		}		
		div +='</div>';		
		efgroup.innerHTML+=div;
	}
	
}
function opendoor(gateId,groupid,typemodel)
{
	var http=BaseUrl+remoteOpen;
	var data={
		gateId:groupid,
		passagewayId:gateId,
		wayType:typemodel
	};
	console.log(JSON.stringify(data));
	_PopMsg();
	_AsyncRequest._AsyncPost(data, 'CallBackopendoor', http,true,CreatHead(),'JSON');
}
function CallBackopendoor(data)
{
	_ErrMsg(data.message);
}
function openalways(gateId,groupid,typemodel,flg)
{
	var http=BaseUrl+remoteSetup;
	var data={
		gateId:groupid,
		passagewayId:gateId,
		wayType:typemodel,
		status:flg
	};
	console.log(JSON.stringify(data));
	_PopMsg();
	_AsyncRequest._AsyncPost(data, 'CallBackopenalways', http,true,CreatHead(),'JSON');	
}
function CallBackopenalways(data)
{
	_ErrMsg(data.message);
}
function listeiff(data)
{
	var eff=document.getElementById('effs');
	eff.innerHTML='';
	if(data.length<=0)
	{
		return;
	}
	var div='';
	for(var x=0;x<data.length;x++)
	{
		if(x==0)
		{
			div +='<input type="checkbox" name="chkeffs" value="'+data[x].id+'" checked="checked" />'+data[x].name;
		}
		else
		{
			div +='<input type="checkbox" name="chkeffs" value="'+data[x].id+'" />'+data[x].name;
		}
	}
	eff.innerHTML=div;
}
function ToMsg()
{
	var Usermothed=document.getElementById('usermothed').value;
	var feventime=document.getElementById('feventime').value;
	var fevent=document.getElementById('fevent').value;	
	var arrfromto=[];
	var arreffs=[];
	var chk=document.getElementsByName('chkeffs');
	for(var x=0;x<chk.length;x++)
	{
		if(chk[x].checked==true)
		{
			arreffs.push(chk[x].value);
		}
	}
	var chk1=document.getElementsByName('chkfromto');
	for(var x=0;x<chk1.length;x++)
	{
		if(chk1[x].checked==true)
		{
			arrfromto.push(chk1[x].value);
		}
	}	
	if(arreffs.length==0)
	{
		_ErrMsg('请选择通知大楼');
		return;
	}
	if(arrfromto.length==0)
	{
		_ErrMsg('请选择通知对象');
		return;
	}	
	if(fevent=='')
	{
		_ErrMsg('请填写通知事件');
		return;
	}	
	if(feventime=='')
	{
		_ErrMsg('请填写事件时间');
		return;
	}	
	if(Usermothed=='')
	{
		_ErrMsg('请填写用户行为');
		return;
	}	

	
	var http=BaseUrl+MsgUrl;
	var data={
		edificeIds:arreffs,
		noticeTypes:arrfromto,
		event:fevent,
		message:Usermothed,
		time:feventime
	};
	_PopMsg();
	document.getElementById('btnmsg').disabled=true;
	//document.getElementById('btnmsg').style.backgroundColor = '#cecece';
	document.getElementById('btnmsg').style.display='none';
	document.getElementById('wrang').style.display='';
	_AsyncRequest._AsyncPost(data, 'CallBackToMsg', http,true,CreatHead());	
	setTimeout(function (){
		document.getElementById('btnmsg').disabled=false;
		//document.getElementById('btnmsg').style.backgroundColor
		document.getElementById('wrang').style.display='none';
		document.getElementById('btnmsg').style.display='';
	},120000);	
}
function CallBackToMsg(data)
{
	console.log(JSON.stringify(data));	
	if(data.code==200)
	{
		_ErrMsg('短信发送完成');
		document.getElementById('usermothed').value='';
		document.getElementById('feventime').value='';
		document.getElementById('fevent').value='';	
		var chk=document.getElementsByName('chkeffs');
		for(var x=0;x<chk.length;x++)
		{
			if(x==0)
			{
				chk[x].checked=true;
			}
			else
			{
				chk[x].checked=false;
			}
		}		
		var chk1=document.getElementsByName('chkfromto');
		for(var x=0;x<chk1.length;x++)
		{
			if(x==0)
			{
				chk1[x].checked=true;
			}
			else
			{
				chk1[x].checked=false;
			}
		}		
	}
}
function StrLenChg(objid,value,msg)
{
	if(value=='' || value.length>100)
	{
		_ErrMsg(msg+'请输入1-100个字符');
		document.getElementById(objid).focus();
		return;
	}
}