﻿var ApiUrl = 'http://127.0.0.1:9999/api/home/';
var GUID = guid().toUpperCase();
/**
 *获取id
 */
function guid() {
    return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random()*16|0, v = c == 'x' ? r : (r&0x3|0x8);
        return v.toString(16);
    });
}
function GetId(Item)
{
	try
	{
		return document.getElementById(Item);
	}
	catch(err){
		_ErrMsg(err.message);
	}
}
function SelChangeItem(Item, ItemValue) {
    var Sel = document.getElementById(Item);
    for (var x = 0; x < Sel.length; x++) {
        if (Sel.options[x].value == ItemValue) {
            Sel.options[x].selected = true;
            break;
        }
    }
}
function GetSelvalue(Item) {
    var Sel = document.getElementById(Item);
    var SelValue = '';
    for (var x = 0; x < Sel.length; x++) {
        if (Sel.options[x].selected == true) {
            SelValue = Sel.options[x].value;
            break;
        }
    }
    return SelValue;
}
function GetSelText(Item) {
    var Sel = document.getElementById(Item);
    var SelValue = '';
    for (var x = 0; x < Sel.length; x++) {
        if (Sel.options[x].selected == true) {
            SelValue = Sel.options[x].text;
            break;
        }
    }
    return SelValue;
}
var _SmartInin = {
    //初始化
    PateStart: function () {
        try {
			_PopMsg();
            _AsyncRequest._AsyncGet('', '_SmartInin.PateStartCallBack', ApiUrl + 'GetConfig');
        }
        catch (err) {
            _ErrMsg(err.message);
        }
    },
    PateStartCallBack: function (Obj) {
        try {
			_ErrMsg('初始化成功');
            if (Obj.Code = '200') {				
                document.getElementById('ip').value = Obj.Data.ServerUrl;
                SelChangeItem('name', Obj.Data.CardType);
                SelChangeItem('rule', Obj.Data.CardRule);                
                document.getElementById('code').value = Obj.Data.ParkCode;
            }
        }
        catch (err) {
            _ErrMsg(err.message);
        }
    },
    ConnionCard: function () {
        try {			
            _AsyncRequest._AsyncGet('', '_SmartInin.ConnionCardCallBack', ApiUrl + 'ConnionCard');
        }
        catch (err) {
			_ErrMsg(err.message);
        }
    },
    ConnionCardCallBack: function (Obj) {
        try {
            if (Obj.Code = '200') {
                document.getElementById('CardYes').style.display = '';
                document.getElementById('CardNo').style.display = 'none';
            }
            else {
                document.getElementById('CardYes').style.display = 'none';
                document.getElementById('CardNo').style.display = '';
            }
			_closeiframe();
        }
        catch (err) {
			_ErrMsg(err.message);
        }
    },
    //获取卡权限
    GetRight: function () {
        var CardNumber = document.getElementById('num').value;
		
        if (CardNumber == '') {
            _ErrMsg('请放入卡片！');
        }
        else {
			if(CardNumber.substr(0,1)=='0')
			{
				CardNumber=CardNumber.substr(1);
			}				
            var data = {
                'cardNo': CardNumber
            };
            var uri = document.getElementById('ip').value;
			_PopMsg();
			try
			{
				_AsyncRequest._AsyncPost(data, '_SmartInin.GetRightCallBack', uri);
			}
			catch(err)
			{
				_ErrMsg(err.message);
			}
        }
    },
    GetRightCallBack: function (Obj) {	
			
        try {
            if (Obj.code == 200) {
                //成功返回数据，提交API写卡				
                if (Obj.data.authinfos.length > 0) {					
					var Card=document.getElementById('num').value;
					if(Card.substr(0,1)=='0')
					{
						Card=Card.substr(1);
					}
                    var Data = {
                        'CardNumber': Card,
                        'authinfos': Obj.data.authinfos,
                        'companyName': Obj.data.companyName,
                        'departmentName': Obj.data.departmentName,
                        'name': Obj.data.name
                    };
                    _AsyncRequest._AsyncPost(Data, '_SmartInin.PostCardCallBack', ApiUrl + 'PostCard');
                }
            }
            else {
                _ErrMsg(Obj.message);
            }
        }
        catch (err) {
			_ErrMsg(err.message);
        }
    },
    PostCardCallBack: function (Obj) {
        try {
			var Card=document.getElementById('num').value;
			if(Card.substr(0,1)=='0')
			{
				Card=Card.substr(1);
			}			
            _ErrMsg(Card + ':' + Obj.Msg);
        }
        catch (err) {
			_ErrMsg(err.message);
        }
        document.getElementById('num').value = '';
    },
    CancelCard: function () {
		_ConfigMsg('清空操作权限，是否确认','_SmartInin.CancelCardTrue()');        
    },
	CancelCardTrue:function(){
		try {
            var CardNo = document.getElementById('num').value;
            if (CardNo == '') {
                _ErrMsg('请放入卡片');
            }
            else {
					if(CardNo.substr(0,1)=='0')
					{
						CardNo=CardNo.substr(1);
					}				
                var Data = {
                    'CardNo': CardNo
                };
				_PopMsg();
                _AsyncRequest._AsyncPost(Data, '_SmartInin.CancelCardCallBack', ApiUrl + 'CancelCard');
            }
        }
        catch (err) {
            _ErrMsg('JS ERR==>'+err.message);
        }
	},
    CancelCardCallBack: function (Obj) {
        try {
			
            _ErrMsg(Obj.Data.CardNo + ':' + Obj.Msg);
        }
        catch (err) {
            _ErrMsg(err.message);
        }
        document.getElementById('num').value = '';
    },
    SaveConfig: function () {
        var ServerUrl = document.getElementById('ip').value;
        var CardType = GetSelvalue('name');
        var CardRule = GetSelvalue('rule');
        var ParkCode = document.getElementById('code').value;
        if (ServerUrl == '') {
            _ErrMsg('平台IP不能为空');
            return;
        }
        if (CardType == '') {
            _ErrMsg('写卡器类型不能为空');
            return;
        }
        if (CardRule == '') {
            _ErrMsg('写卡器规则不能为空');
            return;
        }
        if (ParkCode == '') {
            _ErrMsg('小区码不能为空');
            return;
        }
        var Data = {
            'ServerUrl': ServerUrl,
            'CardType': CardType,
            'CardRule': CardRule,
            'ParkCode': ParkCode
        };
        try {
			_PopMsg();
            _AsyncRequest._AsyncPost(Data, '_SmartInin.SaveConfigCallBack', ApiUrl + 'SaveConfig');
        }
        catch (err) {
            _ErrMsg(err.message);
        }
    },
    SaveConfigCallBack: function (Obj) {        
		_ErrMsg(Obj.Msg);
    }
};
